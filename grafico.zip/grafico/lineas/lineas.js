new Morris.Line({
  // ID of the element in which to draw the chart.
  element: 'myfirstchart',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.
  data: [
    { year: '2008', precio: 80 },
    { year: '2009', precio: 75 },
    { year: '2010', precio: 60 },
    { year: '2011', precio: 30 },
    { year: '2012', precio: 20 }
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'year',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['precio'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['precio'],
  resize: true
});




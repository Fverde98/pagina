<?php
	require 'conexcion.php';	
	$id = $_GET['id'];
	$sql = "SELECT * FROM reservas WHERE id = '$id'";
	$resultado = $mysqli->query($sql);
	$row = $resultado->fetch_array(MYSQLI_ASSOC);
	
?>
<html lang="es">
	<head>
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
			<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/themify-icons.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/style.css">

		<script src="js/jquery-3.5.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>	
	</head>
	
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align:center">MODIFICAR REGISTRO</h3>
			</div>
			
			<form class="form-horizontal" method="POST" action="updatereserva.php" autocomplete="off">
				<div class="form-group">
					<label for="nombre" class="col-sm-2 control-label">nombre</label>
					<div class="col-sm-10">
						<input type="nombre" class="form-control" id="nombre" name="nombre" placeholder="Nombre" value="<?php echo $row['nombre']; ?>" required>
					</div>
				</div>

				<div class="form-group">
					<label for="motivo" class="col-sm-2 control-label">Motivo</label>
					<div class="col-sm-10">
						<select type="motivo" class="form-control" id="motivo" name="motivo" placeholder="Motivo" value="<?php echo $row['motivo']; ?>" 
							                                 >
															<option value="Atencion">Atencion</option>
															<option value="Consulta">Consulta</option>
															 <option value="Adopcion">Adopcion</option>

															>
							</select>
					</div>
				</div>

				<input type="hidden" id="id" name="id" value="<?php echo $row['id']; ?>" />
				
				
				<div class="form-group">
					<label for="telefono" class="col-sm-2 control-label">Telefono</label>
					<div class="col-sm-10">
						<input type="telefono" class="form-control" id="telefono" name="telefono" placeholder="Telefono" value="<?php echo $row['telefono']; ?>"  required>
					</div>
				</div>


				<div class="form-group">
					<label for="hora" class="col-sm-2 control-label">Hora</label>
					<div class="col-sm-10">
						<input type="hora" class="form-control" id="hora" name="hora" placeholder="Hora" value="<?php echo $row['hora']; ?>"  required>
					</div>
				</div>

				<div class="form-group">
					<label for="fecha" class="col-sm-2 control-label">Fecha</label>
					<div class="col-sm-10">
						<input type="fecha" class="form-control" id="date-start" name="fecha" placeholder="Fecha" value="<?php echo $row['fecha']; ?>"  required>
					</div>
				</div>
				
				
				
				
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="editarreserva.php" class="btn btn-default">Regresar</a>
						<button type="submit" class="btn btn-primary">Guardar</button>
					</div>
				</div>
			</form>
		</div>
	</body>
	
</html>
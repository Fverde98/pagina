


<?php

    $usuario = "root"; 
    $password = "";  
    $servidor = "localhost"; 
    $basededatos ="sistemafj"; 



$conexion = mysqli_connect  ($servidor,$usuario,"") or die ("Error con el servidor de la Base de datos"); 



$db = mysqli_select_db($conexion, $basededatos) or die ("Error conexion al conectarse a la Base de datos");


   
    $tipo=$_POST['tipo']; 
    $raza=$_POST['raza'];
    $nombre=$_POST['nombre'];
    $edad=$_POST['edad'];
    $nombred=$_POST['nombred'];
   


     $sql="INSERT INTO mascota VALUES ('','$tipo','$raza','$nombre','$edad','$nombred')"; 

    $ejecutar=mysqli_query($conexion, $sql);



    if(!$ejecutar){
         echo '<script>alert("huvo algun error")</script> ';
         echo "<script>location.href='abonos.php'</script>";   
    }else{
        echo '<script>alert("Sus datos fueron guardados correctamente ")</script> ';
        
        echo "<script>location.href='inicio.php'</script>";  
    }
     
?>﻿
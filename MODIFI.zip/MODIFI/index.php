<!DOCTYPE html>
<html>
<head>
	<title>CRUD</title>
</head>
<body>
     <?php
        include 'conexcion.php';
    $sql=("SELECT * FROM persona");
       $query=mysqli_query($mysqli,$sql);
     ?>
<div>
	<a href="agregar.php">Nuevo</a>
	<table>
		<thead>
		<tr>
			<th>ID</th>
			<th>USUARIO</th>
			<th>EMAIL</th>
			<th>ACCIONES</th>
		</tr>
	</thead>
	<tbody>
		<?php while($filas=mysqli_fetch_array($query)){
			
			?>
			<tr>
				<td><?php echo $filas['Id'] ?></td>
				<td><?php echo $filas['Usuario'] ?></td>
				<td><?php echo $filas['Email'] ?></td>
				<td>
                             <a href="editar.php?id=<?php echo $filas['Id'] ?>">Editar</a>
                             <a href="eliminar.php?id=<?php echo $filas['Id'] ?>">Eliminar</a>

				</td>
			</tr>	
		<?php } ?>
		

	</tbody>
</table>
</div>
</body>
</html>
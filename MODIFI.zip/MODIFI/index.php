<!DOCTYPE html>
<html>
<head>
	<title>CRUD</title>
</head>
<body>
     <?php
        include 'conexcion.php';
       $sql="select * from persona";
       $resultado=mysql_query($sql);
     ?>
<div>
	<table>
		<thead>
		<tr>
			<th>ID</th>
			<th>USUARIO</th>
			<th>EMAIL</th>
			<th>ACCIONES</th>
		</tr>
	</thead>
	<tbody>
		<?php while ($filas=mysql_fetch_assoc($resultado)){
			
			?>
			<tr>
				<td><?php echo $filas['id'] ?></td>
				<td><?php echo $filas['usuario'] ?></td>
				<td><?php echo $filas['email'] ?></td>
				<td>
                             <a href="">Editar</a>
                             <a href="">Eliminar</a>

				</td>
			</tr>	
		<?php } ?>
		

	</tbody>
</table>
</div>
</body>
</html>
<?php
include 'conexcion.php';
$id=$_GET['id'];
$sql="select * from persona where Id='".$id."'";
$resultado=mysql_query($sql);
    while($fila=mysql_fetch_assoc($resultado)) {
?>
<div>
	<form>
		<input type="hidden" name="txtid" value="<?php echo $fila['Id']?>">
		<label>Usuario:</label><br>
		<input type="text" name="txtuser" value="<?php echo $fila['Usuario']?>"><br>
		<label>Email:</label><br>
		<input type="text" name="txtemail" value="<?php echo $fila['Email']?>"><hr>
		<input type="submit" name="" value="Actualizar">
		<a href="index.php">Regresar</a>
	</form>
	<?php } ?>
</div>
<?php
$user=$_GET['txtuser'];
 $email=$_GET['txtemail'];
 if($user!=null||$email!=null) {
 	$sql2="update person set Usuario='".$user."',Email='".$email."' where Id='" .$idp."'";
 	mysql_query($sql2);
 	if($user=1){
 		header("location:index.php");
 	}
  }
?>

<div>
	<form>
		<label>Usuario:</label><br>
		<input type="text" name="txtuser"><br>
		<label>Email:</label><br>
		<input type="text" name="txtemail"><hr>
		<input type="submit" name="" value="Agregar">
		<a href="index.php">Regresar</a>
	</form>
</div>
<?php
 include 'conexcion.php';
 $user=$_GET['txtuser'];
 $email=$_GET['txtemail'];

 if($user!=null||$email!=null) {

 	$sql="insert into persona(usuario,email)values('".$user."','".$email."')";
 	mysql_query($mysqli,$sql);
 	if($user=1){
 		header("location:index.php");
 	}
  }

 ?>
<?php
    $con=mysql_connect("localhost", "root","registro");
    mysql_select_db("registro", $con);
    mysql_query("SET NAME 'utf8'");
?>
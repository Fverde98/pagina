<?php
    $mysqli = new MySQLi("localhost", "root","","sistemafj");
   if ($mysqli -> connect_errno) {
			die( "Fallo la conexción a MySQL: (" . $mysqli -> mysqli_connect_errno() 
				. ") " . $mysqli -> mysqli_connect_error());
		}
		else
			?>
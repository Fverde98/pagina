


<?php

    $usuario = "root"; 
    $password = "";  
    $servidor = "localhost"; 
    $basededatos ="sistemafj"; 



$conexion = mysqli_connect  ($servidor,$usuario,"") or die ("Error con el servidor de la Base de datos"); 



$db = mysqli_select_db($conexion, $basededatos) or die ("Error conexion al conectarse a la Base de datos");


   
    $nombre=$_POST['nombre']; 
    $apellido=$_POST['apellido'];
    $dni=$_POST['dni'];
    $genero=$_POST['genero'];
    $telefono=$_POST['telefono'];
    $email=$_POST['email'];


     $sql="INSERT INTO cliente VALUES ('','$nombre','$apellido','$dni','$genero','$telefono','$email')"; 

    $ejecutar=mysqli_query($conexion, $sql);



    if(!$ejecutar){
         echo '<script>alert("huvo algun error")</script> ';
         echo "<script>location.href='abonos.php'</script>";   
    }else{
        echo '<script>alert("Sus datos fueron guardados correctamente ")</script> ';
        
        echo "<script>location.href='inicio.php'</script>";  
    }
     
?>﻿